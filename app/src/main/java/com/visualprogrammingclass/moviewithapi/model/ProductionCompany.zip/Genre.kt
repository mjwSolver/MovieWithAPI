package com.visualprogrammingclass.moviewithapi.model

data class Genre(
    val id: Int,
    val name: String
)
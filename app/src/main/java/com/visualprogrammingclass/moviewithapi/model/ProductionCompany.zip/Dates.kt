package com.visualprogrammingclass.moviewithapi.model

data class Dates(
    val maximum: String,
    val minimum: String
)